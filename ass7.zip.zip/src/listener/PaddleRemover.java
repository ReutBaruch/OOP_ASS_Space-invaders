package listener;

import gameflow.GameLevel;
import gameobjects.Ball;
import gameobjects.HitListenerForPaddle;
import gameobjects.Paddle;

/**
 * a listener.BlockRemover is in charge of removing blocks from the gameflow.GameLevel.
 * as well as keeping count of the number of blocks that remain.
 */
public class PaddleRemover implements HitListenerForPaddle {
    private GameLevel gameLevel;

    /**
     * constructor.
     * @param gL a game level
     */
    public PaddleRemover(GameLevel gL) {
        this.gameLevel = gL;
    }

    /**
     * This method is called whenever the beingHit object is hit.
     * The hitter parameter is the gameobjects.Ball that's doing the hitting.
     * @param beingHit a block
     * @param hitter the ball
     */
    public void hitEvent(Paddle beingHit, Ball hitter) {
        beingHit.removeFromGame(gameLevel);
        hitter.removeFromGame(gameLevel);
    }
}