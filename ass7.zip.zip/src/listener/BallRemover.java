package listener;

import gameobjects.Ball;
import gameobjects.Block;
import indicator.Counter;
import gameobjects.HitListener;
import gameflow.GameLevel;

/**
 * a listener.BlockRemover is in charge of removing blocks from the gameflow.GameLevel.
 * as well as keeping count
 * of the number of blocks that remain.
 */
public class BallRemover implements HitListener {
    private GameLevel gameLevel;
    private Counter remainingBalls;

    /**
     * constructor.
     * @param gL a game level
     * @param removedBalls counter of balls to remove
     */
    public BallRemover(GameLevel gL, Counter removedBalls) {
        this.gameLevel = gL;
        this.remainingBalls = removedBalls;
    }
    /**
     * This method is called whenever the beingHit object is hit.
     * The hitter parameter is the gameobjects.Ball that's doing the hitting.
     * @param beingHit a block
     * @param hitter the ball
     */
    public void hitEvent(Block beingHit, Ball hitter) {
        hitter.removeFromGame(gameLevel);
        this.remainingBalls.decrease(1);
    }
}