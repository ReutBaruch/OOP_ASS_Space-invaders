package levels;

/**
 * holds information about a set of levels.
 */
public class LevelsSet {
    private String message;
    private String key;
    private String levelDefinitionPath;

    /**
     * constructor.
     */
    public LevelsSet() {
    }

    /**
     * constructor.
     * @param keyTemp type of level
     * @param m message
     * @param levelDefinition a path
     */
    public LevelsSet(String keyTemp, String m, String levelDefinition) {
        this.key = keyTemp;
        this.message = m;
        this.levelDefinitionPath = levelDefinition;
    }

    /**
     * setter.
     * @param m sets a message
     */
    public void setMessage(String m) {
        this.message = m;
    }

    /**
     * setter.
     * @param k sets a key
     */
    public void setKey(String k) {
        this.key = k;
    }

    /**
     * setter.
     * @param levelDefinitionPathTemp a path
     */
    public void setLevelDefinitionPath(String levelDefinitionPathTemp) {
        this.levelDefinitionPath = levelDefinitionPathTemp;
    }

    /**
     * getter.
     * @return a message
     */
    public String getMessage() {
        return this.message;
    }

    /**
     * getter.
     * @return a key
     */
    public String getKey() {
        return this.key;
    }

    /**
     * getter.
     * @return a path
     */
    public String getLevelDefinitionPath() {
        return this.levelDefinitionPath;
    }
}