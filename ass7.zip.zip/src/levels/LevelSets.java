package levels;

import java.io.IOException;
import java.io.LineNumberReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;

/**
 * holds a list of level sets.
 */
public class LevelSets {
    private List<LevelsSet> levelSetList = new ArrayList<>();

    /**
     * add a level to the list.
     * @param levelSet a set of levels
     */
    public void addLevelSet(LevelsSet levelSet) {
        this.levelSetList.add(levelSet);
    }

    /**
     * returns the level sets list.
     * @return the level sets list.
     */
    public List<LevelsSet> getLevelSetList() {
        return this.levelSetList;
    }

    /**
     * creates level sets out of a file.
     * @param reader of the file
     * @return a list of level sets
     * @throws IOException exceptions
     */
    public LevelSets fromReader(Reader reader) throws IOException {
        LevelSets result = new LevelSets();
        LevelsSet currentSet = null;
        LineNumberReader lineReader = null;
        try {
            lineReader = new LineNumberReader(reader);
            String line = null;
            while ((line = lineReader.readLine()) != null) {
                if (lineReader.getLineNumber() % 2 == 0) {
                    currentSet.setLevelDefinitionPath(line.trim());
                    levelSetList.add(currentSet);
                    result.addLevelSet(currentSet);
                    currentSet = null;
                } else {
                    currentSet = new LevelsSet();
                    String[] lineParts = line.trim().split(":");
                    currentSet.setKey(lineParts[0]);
                    currentSet.setMessage(lineParts[1]);
                }
            }
        } finally {
            if (lineReader != null) {
                lineReader.close();
            }
        }
        return result;
    }
}