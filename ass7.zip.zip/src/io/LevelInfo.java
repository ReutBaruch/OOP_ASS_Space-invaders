package io;

import java.util.ArrayList;
import java.util.List;


import gameobjects.LevelInformation;
import gameobjects.Velocity;
import gameobjects.Sprite;
import gameobjects.Block;
import gameobjects.Point;

/**
 * responsible for saving the information on each level.
 * implements LevelInformation
 */
public class LevelInfo implements LevelInformation {
    private static final int SCREEN_MIDDLE = 380;
    private static final int HEIGHT_BORDER = 580;
    private int levelNumber;
    private String levelName;
    private List<Velocity> ballVelocities;
    private Sprite background;
    private int paddleSpeed;
    private int paddleWidth;
    private List<Block> blocks;


    @Override
    public int numberOfBalls() {
        return ballVelocities.size();
    }


    @Override
    public List<Velocity> initialBallVelocities() {
        return ballVelocities;
    }

    @Override
    public int paddleSpeed() {
        return paddleSpeed;
    }

    @Override
    public int paddleWidth() {
        return paddleWidth;
    }

    @Override
    public String levelName() {
        return levelName;
    }

    @Override
    public int getLevelNumber() {
        return levelNumber;
    }

    @Override
    public void setLevelNumber(int num) {
        levelNumber = num;
    }

    @Override
    public Sprite getBackground() {
        return background;
    }

    @Override
    public List<Block> blocks() {
        return blocks;
    }

    @Override
    public int numberOfBlocksToRemove() {
        return blocks.size();
    }

    /**
     * the location of the paddle.
     * @return a point
     */
    @Override
    public Point paddlePoint() {
        Point pointForPaddle = new Point(SCREEN_MIDDLE - (this.paddleWidth / 2), HEIGHT_BORDER - 20);
        return pointForPaddle;
    }

    /**
     * @param name the levelName to set
     */
    public void setLevelName(String name) {
        this.levelName = name;
    }

    /**
     * @param ballV the ballVelocities to set
     */
    public void setBallVelocities(List<Velocity> ballV) {
        this.ballVelocities = ballV;
    }

    /**
     * @param numbers the ballVelocities to set
     */
    public void setBallVelocities(String numbers) {
        this.ballVelocities = new ArrayList<Velocity>();
        String[] numbersString = numbers.split(" ");
        for (String s : numbersString) {
            s = s.trim();
            String[] velocityString = s.split(",");
            double angle = Double.parseDouble(velocityString[0]);
            double speed = Double.parseDouble(velocityString[1]);
            this.ballVelocities.add(Velocity.fromAngleAndSpeed(angle, speed));
        }
    }

    /**
     * @param back the background to set
     */
    public void setBackground(Sprite back) {
        this.background = back;
    }

    /**
     * @param speed the paddleSpeed to set
     */
    public void setPaddleSpeed(int speed) {
        this.paddleSpeed = speed;
    }

    /**
     * @param width the paddleWidth to set
     */
    public void setPaddleWidth(int width) {
        this.paddleWidth = width;
    }

    /**
     * @param blocksList the blocks to set
     */
    public void setBlocks(List<Block> blocksList) {
        this.blocks = blocksList;
    }
}
