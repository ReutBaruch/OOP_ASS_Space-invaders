package indicator;

import gameobjects.Sprite;
import biuoop.DrawSurface;
import gameflow.GameLevel;

import java.awt.Color;

/**
 * knows the current level.
 */
public class LevelIndicator implements Sprite {
    private int level;

    /**
     * constructor.
     * @param level the level name
     */
    public LevelIndicator(int level) {
        this.level = level;
    }

    /**
     * draws the level name on the screen.
     * @param d a drawn surface
     */
    @Override
    public void drawOn(DrawSurface d) {
        d.setColor(Color.BLACK);
        d.drawText(700, 25, "Level: " + level, 20);
    }

    /**
     * not needed.
     * @param dt the change in the velocity
     * @param g a game level
     */
    @Override
    public void timePassed(double dt, GameLevel g) {
    }

    /**
     * adds the indicator to the game.
     * @param g a game level
     */
    public void addToGame(GameLevel g) {
        g.addSprite(this);
    }
}
