package gameobjects;

import biuoop.DrawSurface;
import gameflow.GameLevel;

import java.util.ArrayList;
import java.util.List;

/**
 * responsible of creating a column of aliens.
 */
public class AlienColumn implements Sprite {
    private List<Block> alienColumn;

    /**
     * constructor.
     * @param ac a list of aliens
     */
    public AlienColumn(List<Block> ac) {
        this.alienColumn = ac;
    }

    /**
     * constructor.
     */
    public AlienColumn() {
        this.alienColumn = new ArrayList<Block>();
    }

    /**
     * adds the column to the game.
     * @param g a game level
     */
    public void addToGame(GameLevel g) {
        g.addSprite(this);
    }

    /**
     * adds an alien to the column.
     * @param alien an alien
     */
    public void addAlienToColumn(Block alien) {
        alienColumn.add(alien);
    }

    /**
     * removes the alien from the column.
     * @param alien an alien
     */
    public void removeAlienFromColumn(Block alien) {
        for (int i = 0; i < alienColumn.size(); i++) {
            if (alienColumn.get(i).getCollisionRectangle() == alien.getCollisionRectangle()) {
                alienColumn.remove(alien);
            }
        }
    }

    /**
     * getter.
     * @return column of aliens
     */
    public List<Block> getAliens() {
        return this.alienColumn;
    }

    @Override
    public void drawOn(DrawSurface d) {

    }

    @Override
    public void timePassed(double dt, GameLevel gameLevel) {

    }
}
