package gameobjects;

/**
 * when an object want to know when a hit happened.
 */
public interface HitListenerForPaddle {
    /**
     * This method is called whenever the beingHit object is hit.
     * The hitter parameter is the gameobjects.Ball that's doing the hitting.
     * @param beingHit a block
     * @param hitter the ball
     */
    void hitEvent(Paddle beingHit, Ball hitter);
}
