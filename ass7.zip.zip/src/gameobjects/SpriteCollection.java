package gameobjects;

import biuoop.DrawSurface;
import gameflow.GameLevel;

import java.util.ArrayList;
import java.util.List;

/**
 * the class creates sprites.
 * methods:
 * lets all the the sprites know the time passed
 * draws all the sprites.
 */
public class SpriteCollection {
    private List<Sprite> sprite;

    /**
     * constructor.
     * creates a list of sprites
     */
    public SpriteCollection() {
        this.sprite = new ArrayList<Sprite>();
    }
    /**
     * constructor.
     * receives a list of sprites.
     * @param sprites a list of sprites
     */
    public SpriteCollection(List<Sprite> sprites) {
        this.sprite = sprites;
    }

    /**
     * adds a sprite to the list.
     * @param s a sprite
     */
    public void addSprite(Sprite s) {
        this.sprite.add(s);
    }

    /**
     * accessor.
     * @return a list of sprites
     */
    public List<Sprite> getSprite() {
        return this.sprite;
    }

    /**
     * call timePassed() on all sprites.
     * @param dt the change in the velocity.
     * @param g a game level
     */
    public void notifyAllTimePassed(double dt, GameLevel g) {
        for (int i = 0; i < sprite.size(); i++) {
            sprite.get(i).timePassed(dt, g);
        }
    }

    /**
     * call drawOn(d) on all sprites.
     * @param d a drawn surface
     */
    public void drawAllOn(DrawSurface d) {
        for (int i = 0; i < sprite.size(); i++) {
            sprite.get(i).drawOn(d);
        }
    }

    /**
     * removes a spite from the sprites.
     * @param s a sprite
     */
    public void removeSprite(Sprite s) {
        sprite.remove(s);
    }
}