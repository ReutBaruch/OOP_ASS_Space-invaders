package gameobjects;

import biuoop.DrawSurface;
import biuoop.KeyboardSensor;
import gameflow.GameLevel;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;


/**
 * the class implements the gameobjects.Sprite and gameobjects.Collidable interfaces.
 * the class creates a paddle that can move to the sides and changes
 * an objects velocity when it hits it.
 */
public class Paddle implements Sprite, Collidable, HitNotifierForPaddle {
    private biuoop.KeyboardSensor keyboard;
    private Block paddle;
    private int speed;
    private double time;
    private List<HitListenerForPaddle> hitListeners;
    private List<Ball> shoots;
    private static final int RIGHT_FRAME = 20;
    private static final int LEFT_FRAME = 780;

    /**
     * Construct a paddle.
     * @param b a block (paddle)
     * @param keyboard a keyboard to read the moves
     * @param speed the paddle speed
     */
    public Paddle(Block b, int speed, biuoop.KeyboardSensor keyboard) {
        this.paddle = b;
        this.keyboard = keyboard;
        this.speed = speed;
        this.time = 0.35;
        this.hitListeners = new ArrayList<HitListenerForPaddle>();
        this.shoots = new ArrayList<Ball>();
    }

    /**
     * sets the paddle location.
     * @param x the x coordinate
     * @param y the y coordinate
     */
    public void setPaddlePoint(double x, double y) {
        this.paddle.getCollisionRectangle().getUpperLeft().setX(x);
        this.paddle.getCollisionRectangle().getUpperLeft().setX(x);
        calculatePaddleLines();
    }

    /**
     * sets a keyboard.
     * @param k a given keyboard
     */
    public void setKeyboard(KeyboardSensor k) {
        this.keyboard = k;
    }

    /**
     * sets a paddle.
     * @param b a given block
     */
    public void setPaddle(Block b) {
        this.paddle = b;
    }

    /**
     * moves the paddle to the left when the left arrow was pressed on the keyboard.
     * @param dt the change in the velocity.
     */
    public void moveLeft(double dt) {
        double x = paddle.getCollisionRectangle().getUpperLeft().getX();
        int newSpeed = (int) ((double) speed * dt);
        paddle.getCollisionRectangle().getUpperLeft().setX(x - newSpeed);
        calculatePaddleLines();
    }
    /**
     * moves the paddle to the right when the left arrow was pressed on the keyboard.
     * @param dt the change in the velocity.
     */
    public void moveRight(double dt) {
        double x = paddle.getCollisionRectangle().getUpperLeft().getX();
        int newSpeed = (int) ((double) speed * dt);
        paddle.getCollisionRectangle().getUpperLeft().setX(x + newSpeed);
        calculatePaddleLines();
    }

    /**
     * the function calculate the paddle lines according to his new place.
     * the X coordinate was changed.
     */
    public void calculatePaddleLines() {
        double x = paddle.getCollisionRectangle().getUpperLeft().getX();
        double width = paddle.getCollisionRectangle().getWidth();
        //updates the X lines
        paddle.getCollisionRectangle().getLineX().start().setX(x);
        paddle.getCollisionRectangle().getLineX().end().setX(x + width);
        paddle.getCollisionRectangle().getLineParallelX().start().setX(x);
        paddle.getCollisionRectangle().getLineParallelX().end().setX(x + width);
        //updates the Y lines
        paddle.getCollisionRectangle().getLineY().start().setX(x);
        paddle.getCollisionRectangle().getLineY().end().setX(x);
        paddle.getCollisionRectangle().getLineParallelX().start().setX(x + width);
        paddle.getCollisionRectangle().getLineParallelY().end().setX(x + width);
    }

    /**
     * the function checks if the paddle should move.
     * and makes sure that it doesn't cross the borders.
     * @param dt the change in the velocity.
     * @param game a game level
     */
    public void timePassed(double dt, GameLevel game) {
        double paddleWidth = this.paddle.getCollisionRectangle().getWidth();
        double x = this.paddle.getCollisionRectangle().getUpperLeft().getX();
        double paddleHeight = this.paddle.getCollisionRectangle().getHeight();
        if (keyboard.isPressed(keyboard.LEFT_KEY)) {
            //doesn't cross the left border
            if (this.paddle.getCollisionRectangle().getUpperLeft().getX() <= RIGHT_FRAME) {
                return; // if it crossed - stay put.
            } else {
                moveLeft(dt);
            }
            //doesn't cross the right border
        } else if (keyboard.isPressed(keyboard.RIGHT_KEY)) {
            if (this.paddle.getCollisionRectangle().getUpperLeft().getX() >= (LEFT_FRAME - paddleWidth)) {
                return; // if it crossed - stay put.
            } else {
                moveRight(dt);
            }
        }
        if (keyboard.isPressed("space") && time <= 0) {
            Velocity v = new Velocity(0, -500);
            Ball b = new Ball((int) ((paddleWidth / 2) + x), 550, 5, Color.WHITE, v);
            b.setGame(game.getEnvironment());
            b.addToGame(game);
            shoots.add(b);
            game.getBallsCounter().increase(1);
            time = 0.35;
        } else {
            time = time - dt;
        }
    }

    /**
     * draws the paddle on the screen.
     * @param d a drawn surface
     */
    public void drawOn(DrawSurface d) {
        paddle.drawOn(d);
    }

    /**
     * returns the paddle as a rectangle.
     * @return the paddle's shape
     */
    public Rectangle getCollisionRectangle() {
        return this.paddle.getCollisionRectangle();
    }

    /**
     * changes the velocity of an object that hits it.
     * it spilts the paddle to 5 regions:
     * if it hits the 1:  bounce back with an angle of 300 degrees (-60)
     * for region 2 is should bounce back 330 degrees
     * for 3 region (region 3), it should keep its horizontal direction and only change its vertical one.
     * for region 4 it should bounce in 30 degrees, and for region 5 in 60 degrees.
     * @param collisionPoint the collision point
     * @param currentVelocity the current velocity of an object.
     * @param hitter the ball that hit
     * @return the new velocity.
     */
    public Velocity hit(Ball hitter, Point collisionPoint, Velocity currentVelocity) {
        double width = paddle.getCollisionRectangle().getWidth();
        double startX = paddle.getCollisionRectangle().getLineX().start().getX();
        double endX = paddle.getCollisionRectangle().getLineX().end().getX();
        double split = (width) / 5; //splits to 5 parts
        double part1 = split + startX;
        double part2 = part1 + split;
        double part3 = part2 + split;
        double part4 = part3 + split;
        double dx = currentVelocity.getDx();
        double dy = currentVelocity.getDy();
        //calculates the current speed
        double newSpeed = Math.sqrt(dx * dx + dy * dy);
        //the collision point is on the upper line of the paddle and the object hits from above.
        if ((this.paddle.getCollisionRectangle().getLineX().isRange(collisionPoint)) && (currentVelocity.getDy() > 0)) {
            //it hits the 1 region
            if ((collisionPoint.getX() >= startX) && (collisionPoint.getX() <= part1)) {
                this.notifyHit(hitter);
                return currentVelocity.fromAngleAndSpeed(300, newSpeed);
                //it hits the 2 region
            } else if ((collisionPoint.getX() >= part1) && (collisionPoint.getX() <= part2)) {
                this.notifyHit(hitter);
                return currentVelocity.fromAngleAndSpeed(330, newSpeed);
                //it hits the 3 region
            } else if ((collisionPoint.getX() >= part2) && (collisionPoint.getX() <= part3)) {
                dy = -dy;
                this.notifyHit(hitter);
                return new Velocity(currentVelocity.getDx(), dy);
                //it hits the 4 region
            } else if ((collisionPoint.getX() >= part3) && (collisionPoint.getX() <= part4)) {
                this.notifyHit(hitter);
                return currentVelocity.fromAngleAndSpeed(60, newSpeed);
                //it hits the 5 region
            } else if ((collisionPoint.getX() >= part4) && (collisionPoint.getX() <= endX)) {
                this.notifyHit(hitter);
                return currentVelocity.fromAngleAndSpeed(30, newSpeed);
            }
            //the collision point is on the left line
        } else if (((this.paddle.getCollisionRectangle().getLineY().isRange(collisionPoint)) && (dx < 0))
                && (currentVelocity.getDx() > 0)) {
            dx = (-dx);
            this.notifyHit(hitter);
            return new Velocity(dx, dy);
            //the collision point is on the right line
        } else if (((this.paddle.getCollisionRectangle().getLineParallelY().isRange(collisionPoint)) && (dx > 0))
                && (currentVelocity.getDx() < 0)) {
            dx = (-dx);
            this.notifyHit(hitter);
            return new Velocity(dx, dy);
            //the collision point is on the lower line
        } else if ((((this.paddle.getCollisionRectangle().getLineParallelX().isRange(collisionPoint))) && (dy < 0))
                && (currentVelocity.getDy() < 0)) {
            dy = (-dy);
            this.notifyHit(hitter);
            return new Velocity(currentVelocity.getDx(), dy);
        }
        return currentVelocity;
    }

    /**
     * Add this paddle to the gameflow.
     * @param g gameflow environment
     */
    public void addToGame(GameLevel g) {
        g.addSprite(this);
        g.addCollidable(this);
    }

    /**
     * removes the paddle from the game.
     * @param g a game
     */
    public void removeFromGame(GameLevel g) {
        g.removeSprite(this);
        g.removeCollidable(this);
        g.setHavePaddle(false);
        for (int i = 0; i < shoots.size(); i++) {
            shoots.get(i).removeFromGame(g);
        }
    }

    @Override
    public void addHitListener(HitListenerForPaddle hl) {
        hitListeners.add(hl);

    }

    @Override
    public void removeHitListener(HitListenerForPaddle hl) {
        hitListeners.remove(hl);

    }

    /**
     * notify to all involved that time passed.
     * @param hitter a ball that hit
     */
    private void notifyHit(Ball hitter) {
        // Make a copy of the hitListeners before iterating over them.
        List<HitListenerForPaddle> listeners = new ArrayList<HitListenerForPaddle>(this.hitListeners);
        // Notify all listeners about a hit event:
        for (HitListenerForPaddle hl : listeners) {
            hl.hitEvent(this, hitter);
        }
    }
}