package gameobjects;

/**
 * when an object want to know when a hit happened.
 */
public interface HitNotifierForPaddle {
    /**
     * Add hl as a listener to hit events.
     * @param hl HitListener
     */
    void addHitListener(HitListenerForPaddle hl);
    /**
     * Remove hl from the list of listeners to hit events.
     * @param hl HitListener
     */
    void removeHitListener(HitListenerForPaddle hl);
}
