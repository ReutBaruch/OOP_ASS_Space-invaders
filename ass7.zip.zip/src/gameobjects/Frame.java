package gameobjects;

/**
 * the class creates borders for the ball - a frame.
 */
public class Frame {
    private Point upperPoint;
    private Point lowerPoint;
    /**
     * constructor.
     * @param upper the right upper point
     * @param lower the left lower point
     */
    public Frame(Point upper, Point lower) {
        this.upperPoint = upper;
        this.lowerPoint = lower;
    }
    /**
     * accessor.
     * @return the x coordinate of the right upper point
     */
    public double getUpperX() {
        return this.upperPoint.getX();
    }
    /**
     * accessor.
     * @return the x coordinate of the left lower point
     */
    public double getLowerX() {
        return this.lowerPoint.getX();
    }
    /**
     * accessor.
     * @return the y coordinate of the right upper point
     */
    public double getUpperY() {
        return this.upperPoint.getY();
    }
    /**
     * accessor.
     * @return the y coordinate of the left lower point
     */
    public double getLowerY() {
        return this.lowerPoint.getY();
    }
}