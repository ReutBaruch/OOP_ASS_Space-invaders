package gameobjects;

import biuoop.DrawSurface;
import gameflow.GameLevel;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * responsible of saving all aliens in one group.
 */
public class AlienGroup implements Sprite {
    private List<AlienColumn> columns;
    private double time;
    private double direction;
    private List<Ball> shoots;
    private static final int FRAME_WIDTH = 800;

    /**
     * constructor.
     * @param c a list of aliens columns
     * @param directionTemp a direction the aliens should move to.
     */
    public AlienGroup(List<AlienColumn> c, int directionTemp) {
        this.columns = c;
        this.time = 0.5;
        this.direction = directionTemp;
        shoots = new ArrayList<Ball>();
    }
    /**
     * constructor.
     * @param directionTemp a direction the aliens should move to.
     */
    public AlienGroup(int directionTemp) {
        this.columns = new ArrayList<AlienColumn>();
        this.time = 0.5;
        this.direction = directionTemp;
        shoots = new ArrayList<Ball>();
    }

    /**
     * setter.
     * @param directionTemp a direction the aliens should move to.
     */
    public void setDirection(double directionTemp) {
        this.direction = directionTemp;
    }

    /**
     * getter.
     * @return the list of aliens column
     */
    public List<AlienColumn> getColumns() {
        return this.columns;
    }

    /**
     * adds a column of aliens to the group.
     * @param aliens a column of aliens
     */
    public void addColumn(AlienColumn aliens) {
        columns.add(aliens);
    }

    /**
     * gets the lowest alien.
     * @param columnNum a column index
     * @return the index of lowest alien
     */
    public int getTop(int columnNum) {
        int max = 0;
        int returnNum = 0;
        for (int i = 0; i < this.columns.get(columnNum).getAliens().size(); i++) {
            int y = (int) this.columns.get(columnNum).getAliens().get(i).getCollisionRectangle().getUpperLeft().getY();
            if (y > max) {
                max = y;
                returnNum = i;
            }
        }
        return returnNum;
    }

    /**
     * when alien is killed - remove from group.
     * @param alien an alien
     * @param g a game level
     */
    public void removeFromGroup(Block alien, GameLevel g) {
        for (int i = 0; i < columns.size(); i++) {
            if (columns.get(i).getAliens().size() != 0) {
                for (int j = 0; j < columns.get(i).getAliens().size(); j++) {
                    if (alien.getCollisionRectangle()
                            == this.columns.get(i).getAliens().get(j).getCollisionRectangle()) {
                        this.columns.get(i).removeAlienFromColumn(alien);
                        if (this.columns.get(i).getAliens().size() == 0) {
                            columns.remove(this.columns.get(i));
                        }
                        break;
                    }
                }
            }
        }
    }

    @Override
    public void drawOn(DrawSurface d) {
    }

    /**
     * adds the group of aliens to the game.
     * @param g a game level
     */
    public void addToGame(GameLevel g) {
        g.addSprite(this);
    }

    /**
     * all aliens go down.
     */
    public void setColumnsY() {
        for (int i = 0; i < columns.size(); i++) {
            for (int j = 0; j < columns.get(i).getAliens().size(); j++) {
                double y = columns.get(i).getAliens().get(j).getCollisionRectangle().getUpperLeft().getY();
                columns.get(i).getAliens().get(j).getCollisionRectangle().getUpperLeft().setY(y + 20);
                columns.get(i).getAliens().get(j).getCollisionRectangle().calculatePaddleLines();
            }
        }
    }

    /**
     * all aliens move.
     */
    public void move() {
        if (direction > 0) { ///should move to the right
            double maxLength = this.columns.get(columns.size() - 1).getAliens().get(0).getCollisionRectangle()
                    .getUpperLeft().getX();
            if (maxLength >= FRAME_WIDTH - 40) {
                direction = direction * 1.1;
                direction = direction * (-1);
                setColumnsY();
            }
        } else { //should move to the left
            double minLength = this.columns.get(0).getAliens().get(0).getCollisionRectangle().
                    getUpperLeft().getX();
            if (minLength <= 0) {
                direction = direction * 1.1;
                direction = direction * (-1);
                setColumnsY();
            }
        }
        for (int i = 0; i < columns.size(); i++) { //moves them all
            for (int j = 0; j < columns.get(i).getAliens().size(); j++) {
                double x = columns.get(i).getAliens().get(j).getCollisionRectangle().getUpperLeft().getX();
                columns.get(i).getAliens().get(j).getCollisionRectangle().getUpperLeft().setX(x + direction);
                columns.get(i).getAliens().get(j).getCollisionRectangle().calculatePaddleLines();
            }
        }
    }

    /**
     * aliens can shot and move.
     * @param dt the change in the velocity.
     * @param g a game level
     */
    public void timePassed(double dt, GameLevel g) {
        if (columns.size() > 0) {
            Random rand = new Random();
            int number = rand.nextInt(columns.size());
            int top = getTop(number);
            if (this.columns.get(number) != null) {
                double x = this.columns.get(number).getAliens().get(top).getCollisionRectangle().getUpperLeft().getX();
                double y = this.columns.get(number).getAliens().get(top).getCollisionRectangle().getUpperLeft().getY();
                double width = this.columns.get(number).getAliens().get(top).getCollisionRectangle().getWidth();
                if (time <= 0) {
                    Velocity v = new Velocity(0, 500);
                    Ball b = new Ball((int) ((width / 2) + x), (int) y + 50, 7, Color.RED, v);
                    b.setGame(g.getEnvironment());
                    b.addToGame(g);
                    shoots.add(b);
                    g.getBallsCounter().increase(1);
                    time = 0.5;
                } else {
                    time = time - dt;
                }
                move();
                if (columns.get(0).getAliens().get(0).getCollisionRectangle().getUpperLeft().getY() >= 400) {
                    g.getLivesCounter().decrease(1);
                    setBlocksToStart(g);
                }
            }
        }
    }

    /**
     * reset the aliens to the top.
     * @param gameLevel a game level
     */
    public void setBlocksToStart(GameLevel gameLevel) {
        double x = 35;
        double y = 60;
        double width = columns.get(0).getAliens().get(0).getCollisionRectangle().getWidth();
        double height = columns.get(0).getAliens().get(0).getCollisionRectangle().getHeight();
        direction = gameLevel.getLevelNumber();
        for (int i = 0; i < shoots.size(); i++) {
            shoots.get(i).removeFromGame(gameLevel);
        }
        for (int i = 0; i < columns.size(); i++) {
            for (int j = 0; j < columns.get(i).getAliens().size(); j++) {
                columns.get(i).getAliens().get(j).setRect(columns.get(i).getAliens().get(j).getOriginalRect());
            }
        }
    }
}
