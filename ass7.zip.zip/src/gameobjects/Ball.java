package gameobjects;

import biuoop.DrawSurface;
import gameflow.GameLevel;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.awt.Color;

/**
 * the class creates a ball and preforms the following methods.
 * it can create a ball using different constructor
 * draws the ball on a surface.
 * move the ball a step and makes sure the ball doesn't cross the borders.
 */
public class Ball implements Sprite, HitListener {
    private Point center;
    private int radius;
    private Color color;
    private Velocity velocity;
    private Frame frame;
    private GameEnvironment game;
    private List<HitListener> hitListeners;
    private static final int WIDTH_START_BORDER = 20;
    private static final int WIDTH_END_BORDER = 780;
    private static final int HEIGHT_BORDER = 580;
    /**
     * constructor.
     * @param center the center point of the ball
     * @param r the radius of the ball
     * @param color the color of the ball
     * @param upper the left upper point of the frame - the boundaries of the ball
     * @param lower the right lower point of the frame - the boundaries of the ball
     * @param dx the dx of the velocity
     * @param dy the dy of the velocity
     */
    /*public Ball(Point center, int r, java.awt.Color color, Point upper, Point lower, double dx, double dy) {
        this.center = center;
        this.radius = r;
        this.color = color;
        this.velocity = new Velocity(dx, dy);
        this.frame = new Frame(upper, lower);
        this.hitListeners = new ArrayList<HitListener>();
    }*/
    /**
     * constructor.
     * @param x the x coordinate of the center point
     * @param y the y coordinate of the center point
     * @param r the radius of the circle
     * @param color the color of the ball
     * @param otherVelocity the velocity
     */
    public Ball(int x, int y, int r, java.awt.Color color, Velocity otherVelocity) {
        this.center = new Point(x, y);
        this.radius = r;
        this.color = color;
        this.velocity = otherVelocity;
        //this.frame = new Frame(upper, lower);
        this.hitListeners = new ArrayList<HitListener>();
    }

    /**
     * constructor - choose the center point randomly.
     * choose thr velocity in coordinate with the radius.
     * @param newRadius the radius of the ball
     * @param upper the left upper point of the frame - the boundaries of the ball
     * @param lower the right lower point of the frame - the boundaries of the ball
     */
    public Ball(int newRadius, Point upper, Point lower) {
        Random rand = new Random();
        this.frame = new Frame(upper, lower);
        int x = rand.nextInt((int) frame.getLowerX()) + 1; // get integer in range 1-the border
        int y = rand.nextInt((int) frame.getLowerY()) + 1; // get integer in range 1-the border
        double dx;
        double dy;
        this.radius = newRadius;
        if (newRadius > 50) { //all radius above 50 should have the same radius
            dx = (double) 10;
            dy = (double) 100 / 50;
        } else {
            dx = (double) 10;
            dy = (double) 100 / newRadius;
        }
        int colorTemp = rand.nextInt(5); // get integer in range 0-5
        Point centerTemp = new Point(x, y);
        this.radius = newRadius; //set radius
        this.center = centerTemp; //set center
        this.velocity = new Velocity(dx, dy); //set velocity
        this.hitListeners = new ArrayList<HitListener>();
        switch (colorTemp) { //different colors for balls
            case (0):
                this.color = Color.red;
                break;
            case (1):
                this.color = Color.green;
                break;
            case (2):
                this.color = Color.CYAN;
                break;
            case (3):
                this.color = Color.LIGHT_GRAY;
                break;
            case (4):
                this.color = Color.MAGENTA;
                break;
            case (5):
                this.color = Color.pink;
                break;
            default:
                this.color = Color.pink;
        }
    }
    /**
     * accessor.
     * @return the x coordinate of the center
     */
    public int getX() {
        return (int) this.center.getX();
    }
    /**
     * accessor.
     * @return the y coordinate of the center
     */
    public int getY() {
        return (int) this.center.getY();
    }
    /**
     * accessor.
     * @return the radius of the ball.
     */
    public int getRadius() {
        return (int) this.radius;
    }
    /**
     * accessor.
     * @return the size of the ball 2*PI*RADIUS
     */
    public int getSize() {
        return (int) (2 * Math.PI * this.radius);
    }

    /**
     * accessor.
     * @return  tha center point
     */
    public Point getCenter() {
        return this.center;
    }

    /**
     * accessor.
     * @return the frame.
     */
    public Frame getFrame() {
        return this.frame;
    }
    /**
     * accessor.
     * @return the color of the ball
     */
    public java.awt.Color getColor() {
        return this.color;
    }
    /**
     * accessor.
     * @return the velocity of the ball
     */
    public Velocity getVelocity() {
        return this.velocity;
    }
    /**
     * set the frame for the ball.
     * @param upper the left upper point of the frame - the boundaries of the ball
     * @param lower the right lower point of the frame - the boundaries of the ball
     */
    public void setFrame(Point upper, Point lower) {
        this.frame = new Frame(upper, lower);
    }
    /**
     * set the velocity of the ball.
     * @param v the wanted velocity
     */
    public void setVelocity(Velocity v) {
        this.velocity = v;
    }
    /**
     * set the velocity of the ball.
     * @param dx the dx part of the velocity
     * @param dy the dy part of the velocity
     */
    public void setVelocity(double dx, double dy) {
        this.velocity.setDx(dx);
        this.velocity.setDy(dy);
    }

    /**
     * sets the gameflow.
     * @param otherGame a gameflow environment
     */
    public void setGame(GameEnvironment otherGame) {
        this.game = otherGame;
    }
    /**
     * draws the ball on the surface.
     * @param surface the surface the ball should be drawn on.
     */
   public void drawOn(DrawSurface surface) {
       surface.setColor(Color.WHITE);
       surface.drawCircle(this.getX(), this.getY(), this.getRadius());
       surface.setColor(this.color);
       surface.fillCircle(this.getX(), this.getY(), this.getRadius());
    }

    /**
     * tells the ball time passed.
     * @param dt the change in the velocity.
     * @param g a game level
     */
    public void timePassed(double dt, GameLevel g) {
       moveOneStep(dt, g);
    }

    /**
     * adds the ball to the gameflow.
     * @param g a gameflow
     */
    public void addToGame(GameLevel g) {
       g.addSprite(this);
    }

    /**
     * the function initialize the ball's center so i wouldn't cross the frame's borders.
     */
    /*public void initializeCenter() {
        //if it about to hit the right frame
        if (this.center.getX() - radius <= this.frame.getUpperX() + WIDTH_START_BORDER) {
            this.center.setX(WIDTH_START_BORDER + radius + 1);
            if (this.velocity.getDx() < 0) {
                this.velocity.setDx(-this.velocity.getDx());
            }
        }
        //if it about to hit the left frame
        if (this.center.getX()  >= WIDTH_END_BORDER) {
            this.center.setX(WIDTH_END_BORDER - 1);
            if (this.velocity.getDx() > 0) {
                this.velocity.setDx(-this.velocity.getDx());
            }
        }
        //if it about to hit the upper frame
        if (this.center.getY() <= WIDTH_START_BORDER) {
            this.center.setY(WIDTH_START_BORDER + 1);
            if (this.velocity.getDy() < 0) {
                this.velocity.setDy(-this.velocity.getDy());
            }
        }
        //if it about to hit the lower frame - not needed in this assignment
        if (this.center.getY() >= HEIGHT_BORDER) {
            this.center.setY(HEIGHT_BORDER - 1);
            if (this.velocity.getDy() > 0) {
                this.velocity.setDy(-this.velocity.getDy());
            }
        }
    }*/
    /**
     * the function moves the ball a step and ,makes sure that it doesn't go out of the borders.
     * @param dt the change in the velocity.
     * @param gameLevel a game level
     */
    public void moveOneStep(double dt, GameLevel gameLevel) {
        if (this.game == null) {
            return;
        }
        CollisionInfo collInfo;
        Velocity velocityDt = new Velocity(this.velocity.getDx() * dt, this.velocity.getDy() * dt);
        Point end = velocityDt.applyToPoint(this.center); //the next step the ball should make
        Point start = this.center;
        Line trajectory = new Line(start, end);
        collInfo = this.game.getClosestCollision(trajectory); //receives the closest intersection point
        if (collInfo != null) { //if there is an intersection
            gameLevel.getBallsCounter().decrease(1);
            //calls the hit function to change the velocity according to the object it hits
            Velocity velocityTemp = collInfo.collisionObject().hit(this, collInfo.collisionPoint(), this.velocity);
            if (velocityTemp != null) {
                Point tempPoint = collInfo.collisionPoint();
                if (this.velocity.getDx() > 0) {
                    tempPoint.setX(tempPoint.getX() - 1);
                } else if (this.velocity.getDx() < 0) {
                    tempPoint.setX(tempPoint.getX() + 1);
                }
                if (this.velocity.getDy() > 0) {
                    tempPoint.setY(tempPoint.getY() - 1);
                } else if (this.velocity.getDy() < 0) {
                    tempPoint.setY(tempPoint.getY() + 1);
                }
                this.center = collInfo.collisionPoint();
                //this.center = this.getVelocity().applyToPoint(this.center); //makes the next move
                this.velocity = velocityTemp;
         //       initializeCenter(); //makes sure it doesn't cross the borders
                this.removeFromGame(gameLevel);
            }
        } else { //there was no intersection
            this.center = end;
        }
    }
    /**
     * This method is called whenever the beingHit object is hit.
     * The hitter parameter is the gameobjects.Ball that's doing the hitting.
     * @param beingHit a block
     * @param hitter the ball
     */
    public void hitEvent(Block beingHit, Ball hitter) {
        beingHit.addHitListener(hitter);
    }

    /**
     * removes the ball from the game.
     * @param gameLevel the game it should be removed from
     */
    public void removeFromGame(GameLevel gameLevel) {
        gameLevel.removeSprite(this);
    }
}
