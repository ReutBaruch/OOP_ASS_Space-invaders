package gameobjects;

import java.util.ArrayList;
import java.util.List;

/**
 * the class creates a gameflow environment for the gameflow.
 */
public class GameEnvironment {
    private List<Collidable> coll;

    /**
     * creates a list of collidables.
     */
    public GameEnvironment() {
        this.coll = new ArrayList<Collidable>();
    }
    /**
     * add the given collidable to the environment.
     * @param coll a list of collidables
     */
    public GameEnvironment(List coll) {
        this.coll = coll;
    }

    /**
     * adds a collidable to th list.
     * @param c a collidable
     */
    public void addCollidable(Collidable c) {
        coll.add(c);
    }

    /**
     * accessor.
     * @return a list of collidables
     */
    public List<Collidable> getColllidable() {
        return this.coll;
    }

    /**
     *the function finds the closes intersection point andreturns the information about it.
     * @param trajectory a line
     * @return If this object will not collide with any of the collidables
     * in this collection, return null. Else, return the information
     * about the closest collision that is going to occur.
     */
    public CollisionInfo getClosestCollision(Line trajectory) {
        if (trajectory == null) {
            return null; //no line was recived
        }
        if (coll.size() == 0) {
            return null; //there are no collidables
        }
        Point closesIntersect = null;
        int rememberIndex = 0;
        List<Point> intersectionPoints = new ArrayList<>();
        List<Collidable> tempRect = new ArrayList<>();
        Rectangle rect;
        //checks intersection point for each coolidable
        for (int i = 0; i < coll.size(); i++) {
            rect = coll.get(i).getCollisionRectangle();
            Point tempPoint = trajectory.closestIntersectionToStartOfLine(rect);
            if (tempPoint != null) {
                intersectionPoints.add(tempPoint); //adds the point to the list
                tempRect.add(coll.get(i)); //saves the shape of the coolidable
            }
        }
        if (intersectionPoints.size() == 0) {
            return null; //there are no intersection points
        }
        //finds the closest intersection point
        closesIntersect = trajectory.minDistancePoint(intersectionPoints);
        //finds the point in the list to find the collidable
        for (int i = 0; i < intersectionPoints.size(); i++) {
            if (intersectionPoints.get(i).equals(closesIntersect)) {
                rememberIndex = i;
                break;
            }
        }
        //return the information about the point and the collidable
        return new CollisionInfo(closesIntersect, tempRect.get(rememberIndex));
    }

    /**
     * removes the collidable from the game.
     * @param c a collidable
     */
    public void removeCollidable(Collidable c) {
        coll.remove(c);
    }
}
