package gameobjects;

import biuoop.DrawSurface;
import gameflow.GameLevel;

/**
 * gameobjects.Sprite interface.
 */
public interface Sprite {
    /**
     * draw the sprite to the screen.
     * @param d a drawn surface
     */
    void drawOn(DrawSurface d);

    /**
     * notify the sprite that time has passed.
     * @param dt the change in the velocity.
     * @param gameLevel a game level
     */
    void timePassed(double dt, GameLevel gameLevel);
}