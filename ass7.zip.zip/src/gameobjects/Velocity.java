package gameobjects;

/**
 * the class creates a velocity for a ball.
 */
public class Velocity {
    private double dx;
    private double dy;
    /**
     * constructor.
     * @param dx the dx of the velocity.
     * @param dy the dy of the velocity.
     */
    public Velocity(double dx, double dy) {
        this.dx = dx;
        this.dy = dy;
    }
    /**
     * constructor.
     * @param angle the angel the ball moves in.
     * @param speed the speed of the ball
     * @return the new velocity.
     */
    public static Velocity fromAngleAndSpeed(double angle, double speed) {
        double newDx = speed * Math.sin(Math.toRadians(angle));
        double newDy = speed * -Math.cos(Math.toRadians(angle));
        return new Velocity(newDx, newDy);
    }
    /**
     * set the dx of the velocity.
     * @param otherDx the dx of the velocity.
     */
    public void setDx(double otherDx) {
        this.dx = otherDx;
    }
    /**
     * set the dy of the velocity.
     * @param otherDy the dx of the velocity.
     */
    public void setDy(double otherDy) {
        this.dy = otherDy;
    }
    /**
     * accessor.
     * @return the dx of the velocity.
     */
    public double getDx() {
        return this.dx;
    }
    /**
     * accessor.
     * @return the dy of the velocity.
     */
    public double getDy() {
        return this.dy;
    }
    /**
     * Take a point with position (x,y) and return a new point.
     * with position (x+dx, y+dy)
     * @param p the original point
     * @return the new point (x+dx, y+dy)
     */
    public Point applyToPoint(Point p) {
        double x = p.getX();
        double y = p.getY();
        Point point = new Point(x + dx, y + dy);
        return point;
    }
}