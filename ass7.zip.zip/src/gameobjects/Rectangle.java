package gameobjects;

import animation.Drawable;
import biuoop.DrawSurface;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/**
 * the class creates rectangles.
 * methods:
 * finds intersection between a line and a rectangle.
 */
public class Rectangle implements Drawable {
    private Point upperLeft;
    private double width;
    private double height;
    private Point upperRight;
    private Point lowerLeft;
    private Point lowerRight;
    private Line lineX;
    private Line lineY;
    private Line lineParallelX;
    private Line lineParallelY;
    private Color color;
    private boolean isFilled;

    /**
     * Construct a rectangle.
     * @param upperLeft the upper left point of a rectangle
     * @param width the width of a rectangle
     * @param height the height of a rectangle
     */
    public Rectangle(Point upperLeft, double width, double height) {
        this.upperLeft = upperLeft;
        //creates the upper right point using the given data
        this.upperRight = new Point((upperLeft.getX() + width), upperLeft.getY());
        //creates the lower left point using the given data
        this.lowerLeft = new Point(upperLeft.getX(), (upperLeft.getY() + height));
        //creates the lower right point using the given data
        this.lowerRight = new Point((upperLeft.getX() + width), (upperLeft.getY() + height));
        this.width = width;
        this.height = height;
        //creates the upper line of a rectangle
        this.lineX = new Line(this.upperLeft, this.upperRight);
        //creates the most left line of a rectangle
        this.lineY = new Line(this.upperLeft, this.lowerLeft);
        //creates the lower line of a rectangle
        this.lineParallelX = new Line(this.lowerLeft, this.lowerRight);
        //creates the most right line of a rectangle
        this.lineParallelY = new Line(this.upperRight, this.lowerRight);
    }

    /**
     * sets the color.
     * @param c a color
     */
    public void setColor(Color c) {
        this.color = c;
    }
    /**
     * if it is filled.
     * @param value true or false
     */
    public void setFilled(boolean value) {
        this.isFilled = value;
    }

    /**
     * the function calculates intersection points between a given line.
     * and a rectangle.
     * @param line a given line
     * @return a list of intersection points
     */
    public List<Point> intersectionPoints(Line line) {
        List<Point> listOfPoints = new ArrayList<>();
        Point intersection;
        //finds intersection between a given line and the upper line of a rectangle
        intersection = this.lineX.calculateIntersecting(line);
        if (intersection != null) {
            listOfPoints.add(intersection); //adds the point to the list
        }
        //finds intersection between a given line and the most left line of a rectangle
        intersection = this.lineY.calculateIntersecting(line);
        if (intersection != null) {
            listOfPoints.add(intersection); //adds the point to the list
        }
        //finds intersection between a given line and the lower line of a rectangle
        intersection = this.lineParallelX.calculateIntersecting(line);
        if (intersection != null) {
            listOfPoints.add(intersection); //adds the point to the list
        }
        //finds intersection between a given line and the most right line of a rectangle
        intersection = this.lineParallelY.calculateIntersecting(line);
        if (intersection != null) {
            listOfPoints.add(intersection); //adds the point to the list
        }
        if (listOfPoints.size() == 0) {
            return null; //no points
        } else {
            return listOfPoints; //returns the list of intersection points
        }
    }

    /**
     * accessor.
     * @return Return the width of the rectangle
     */
    public double getWidth() {
        return this.width;
    }
    /**
     * accessor.
     * @return Return the height of the rectangle
     */
    public double getHeight() {
        return this.height;
    }
    /**
     * accessor.
     * @return Returns the upper left point of the rectangle.
     */
    public Point getUpperLeft() {
        return this.upperLeft;
    }
    /**
     * accessor.
     * @return Returns the Lower right point of the rectangle.
     */
    public Point getLowerRight() {
        return this.lowerRight;
    }
    /**
     * accessor.
     * @return Returns the upper line of the rectangle.
     */
    public Line getLineX() {
        return this.lineX;
    }
    /**
     * accessor.
     * @return Returns the left line of the rectangle.
     */
    public Line getLineY() {
        return this.lineY;
    }
    /**
     * accessor.
     * @return Returns the lower line of the rectangle.
     */
    public Line getLineParallelX() {
        return this.lineParallelX;
    }
    /**
     * accessor.
     * @return Returns the right line of the rectangle.
     */
    public Line getLineParallelY() {
        return this.lineParallelY;
    }
    /**
     * draws the shape to the screen.
     * @param d a draw surface
     */
    @Override
    public void draw(DrawSurface d) {
        d.setColor(color);
        if (isFilled) {
            d.fillRectangle((int) upperLeft.getX(), (int) upperLeft.getY(),
                    (int) width, (int) height);
        } else {
            d.drawRectangle((int) upperLeft.getX(), (int) upperLeft.getY(),
                    (int) width, (int) height);
        }
    }

    /**
     * the function calculate the paddle lines according to his new place.
     * the X coordinate was changed.
     */
    public void calculatePaddleLines() {
        double x = this.getUpperLeft().getX();
        double w = this.getWidth();
        //updates the X lines
        this.getLineX().start().setX(x);
        this.getLineX().end().setX(x + w);
        this.getLineParallelX().start().setX(x);
        this.getLineParallelX().end().setX(x + w);
        //updates the Y lines
        this.getLineY().start().setX(x);
        this.getLineY().end().setX(x);
        this.getLineParallelX().start().setX(x + w);
        this.getLineParallelY().end().setX(x + w);
    }
}