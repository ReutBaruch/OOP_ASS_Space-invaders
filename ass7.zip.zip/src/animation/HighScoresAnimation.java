package animation;

import biuoop.DrawSurface;
import gameflow.HighScoresTable;
import java.awt.Color;

/**
 * the class is responsible for showing an high score table.
 */
public class HighScoresAnimation implements Animation {
    private HighScoresTable highScoresTable;
    private boolean stop;

    /**
     * constructor.
     * @param scores an high score table
     */
    public HighScoresAnimation(HighScoresTable scores) { //}, String endKey, KeyboardSensor k) {
        this.highScoresTable = scores;
    }


    @Override
    /**
     * runs each frame of the game and takes care of the game logic.
     * @param d a draw surface.
     * @param dt the change in the velocity.
     */
    public void doOneFrame(DrawSurface d, double dt) {
        d.setColor(Color.pink);
        d.fillRectangle(0, 0, 900, 900);
        d.setColor(Color.CYAN);
        d.drawText(10, 100, "Player Name", 26);
        d.drawText(200, 100, "Player Score", 26);
        d.drawLine(10, 110, 400, 110);
        d.setColor(Color.GRAY);
        for (int i = 0; i < highScoresTable.getTable().size(); i++) {
            d.drawText(10, 150 + (i * 35), highScoresTable.getTable().get(i).getName(), 24);
            d.drawText(200, 150 + (i * 35), Integer.valueOf(
                    highScoresTable.getTable().get(i).getScore()).toString(), 24);
        }
    }

    @Override
    /**
     * stop condition.
     * @return true or false
     */
    public boolean shouldStop() {
        return false;
    }
}
