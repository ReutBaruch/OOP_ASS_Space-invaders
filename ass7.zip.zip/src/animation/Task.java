package animation;

/**
 * an interface to run a task.
 * @param <T> can receive any object
 */
public interface Task<T> {
    /**
     * runs the task.
     * @return an object
     */
    T run();
}
