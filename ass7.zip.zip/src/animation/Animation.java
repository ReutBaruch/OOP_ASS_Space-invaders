package animation;

import biuoop.DrawSurface;

/**
 * animation interface.
 */
public interface Animation {

    /**
     * runs each frame of the game and takes care of the game logic.
     * @param d a draw surface.
     * @param dt the change in the velocity
     */
    void doOneFrame(DrawSurface d, double dt);

    /**
     * stop condition.
     * @return true or false
     */
    boolean shouldStop();
}
