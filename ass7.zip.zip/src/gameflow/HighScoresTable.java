package gameflow;

import java.io.Serializable;
import java.io.File;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.FileInputStream;
import java.io.ObjectOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Create an empty high-scores table with the specified tableSize.
 * The tableSize means that the table holds up to tableSize top scores.
 */
public class HighScoresTable implements Serializable {
    private List<ScoreInfo> table;
    private int tableSize;

    /**
     * constructor.
     * @param size a table size.
     */
    public HighScoresTable(int size) {
        this.tableSize = size;
        this.table = new ArrayList<ScoreInfo>();
    }

    /**
     * returns the table with the scores.
     * @return the table
     */
    public List<ScoreInfo> getTable() {
        return this.table;
    }
    /**
     * adds a score to the table.
     * @param score a score
     */
    public void add(ScoreInfo score) {
        if (table.size() == 0) { // if its an empty list
            table.add(score);
        } else if (table.size() < tableSize) { //the list still have space
            //the new score is the lowest
            if (table.get(table.size() - 1).getScore() > score.getScore()) {
                table.add(score);
                //the new score is somewhere in between
            } else {
                for (int i = 0; i < table.size(); i++) {
                    if (table.get(i).getScore() <= score.getScore()) {
                        for (int j = i; j < table.size() - 1; j++) {
                            table.add(j + 1, table.get(j));
                        }
                        table.add(i, score);
                        break;
                    }
                }
            }
        } else if (table.size() == tableSize) { //table is full
            for (int i = 0; i < table.size(); i++) {
                if (table.get(i).getScore() <= score.getScore()) {
                    table.remove(i);
                    table.add(i, score);
                    break;
                }
            }
        }
    }
    /**
     * Return table tableSize.
     * @return Return table tableSize.
     */
    public int size() {
        return tableSize;
    }
    /**
     * Return the current high scores.
     * The list is sorted such that the highest
     * scores come first.
     * @return the scores table
     */
    public List<ScoreInfo> getHighScores() {
        return table;
    }

    /**
     * return the rank of the current score: where will it
     * be on the list if added?
     * Rank 1 means the score will be highest on the list.
     * Rank `tableSize` means the score will be lowest.
     * Rank > `tableSize` means the score is too low and will not
     * be added to the list.
     * @param score a score
     * @return the score rank
     */
    public int getRank(int score) {
        if (table.isEmpty()) {
            return 1;
        }
        for (int i = 0; i < table.size(); i++) {
            if (score >= table.get(i).getScore()) {
                return i + 1;
            }
        }
        return tableSize + 1;
    }
    /**
     * Clears the table.
     */
    public void clear() {
        for (int i = 0; i < table.size(); i++) {
            table.remove(i);
        }
    }

    /**
     * Load table data from file.
     * Current table data is cleared.
     * @param filename a file name
     * @throws IOException an exception
     */
    public void load(File filename) throws IOException {
        clear();
        HighScoresTable highScoresTable = loadFromFile(filename);
        if (highScoresTable != null) {
            this.tableSize = highScoresTable.tableSize;
            this.table = highScoresTable.table;
        }
    }
    /**
     * Save table data to the specified file.
     * @param filename a file name
     * @throws IOException an exception
     */
    public void save(File filename) throws IOException {

        ObjectOutputStream objectOutputStream = null;
        try {
            objectOutputStream = new ObjectOutputStream(new FileOutputStream(filename));
            objectOutputStream.writeObject(this);
        } catch (IOException e) {
            System.err.println("Failed saving object");
            e.printStackTrace(System.err);
        } finally {
            try {
                if (objectOutputStream != null) {
                    objectOutputStream.close();
                }
            } catch (IOException e) {
                System.err.println("Failed closing file: " + filename);
            }
        }
    }
    /**
     * Read a table from file and return it.
     * If the file does not exist, or there is a problem with
     * reading it, an empty table is returned.
     * @param filename a file name
     * @return the scores table
     */
    public static HighScoresTable loadFromFile(File filename) {
        ObjectInputStream objectInputStream = null;
        try {

            objectInputStream = new ObjectInputStream(new FileInputStream(filename));
            return (HighScoresTable) objectInputStream.readObject();

        } catch (FileNotFoundException e) { // Can't find file to open
            System.err.println("Unable to find file: " + filename);
            return null;
        } catch (ClassNotFoundException e) { // The class in the stream is unknown to the JVM
            System.err.println("Unable to find class for object in file: " + filename);
            return null;
        } catch (IOException e) { // Some other problem
            System.err.println("Failed reading object");
            e.printStackTrace(System.err);
            return null;
        } finally {
            try {
                if (objectInputStream != null) {
                    objectInputStream.close();
                }
            } catch (IOException e) {
                System.err.println("Failed closing file: " + filename);
            }
        }
    }
}
