package gameflow;

import animation.AnimationRunner;
import animation.KeyPressStoppableAnimation;
import animation.EndScreenLose;
import animation.HighScoresAnimation;
import animation.Task;
import animation.Menu;
import animation.MenuAnimation;
import biuoop.DialogManager;
import indicator.Counter;
import gameobjects.LevelInformation;
import biuoop.GUI;
import biuoop.KeyboardSensor;
import levels.LevelSets;
import io.LevelSpecificationReader;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 * in charge of creating the differnet levels, and moving from one level to the next.
 */
public class GameFlow {
    private KeyboardSensor keyboardSensor;
    private AnimationRunner animationRunner;
    private GUI gui;
    private Counter livesCounter;
    private Counter score;
    private HighScoresTable table;
    private DialogManager dialog;
    private int levelNumber = 1;
    private List<LevelInformation> levels;

    /**
     * constructor.
     *
     * @param levels returns the game's levels
     */
    public GameFlow(List<LevelInformation> levels) {
        this.gui = new GUI("space-invaders", 800, 600); //creates new screen
        dialog = gui.getDialogManager();
        this.keyboardSensor = gui.getKeyboardSensor();
        this.animationRunner = new AnimationRunner(3, gui);
        this.livesCounter = new Counter();
        this.livesCounter.setCount(7);
        this.score = new Counter();
        livesCounter.increase(7);
        table = new HighScoresTable(4);
        this.levels = levels;
    }

    /**
     * runs a set of level.
     *
     * @param levelsSet a set of levels to run
     */
    public void runLevels(List<LevelInformation> levelsSet) {
        if (levelsSet.get(0).getLevelNumber() == 0) {
            levelsSet.get(0).setLevelNumber(1);
        }
        File highscores = new File("highscores");
        //this.livesCounter.setCount(7);
        this.score.setCount(0);
        if (highscores.exists()) {
            try {
                table.load(highscores); //saves changes
            } catch (IOException e) {
                System.out.println(e);
            }
        } else { //creates a score table
            try {
                table.save(highscores);
            } catch (IOException e) {
                System.out.println(e);
            }
        }
        for (LevelInformation levelInfo : levelsSet) {
            GameLevel level = new GameLevel(levelInfo, animationRunner, score, livesCounter, keyboardSensor,
                    gui, levelNumber);
            level.initialize();
            livesCounter.setCount(7);
            //level has more blocks and player has more lives
            while (livesCounter.getValue() != 0) {
                level.playOneTurn();
                if (level.getBlockCounter().getValue() == 0) {
                    this.levelNumber = this.levelNumber + 1;
                    List<LevelInformation> subLevels = new ArrayList<>();
                    InputStream is = ClassLoader.getSystemClassLoader().getResourceAsStream("resources/definitions/"
                            + "space_invaders_definitions.txt");
                    subLevels = new LevelSpecificationReader().fromReader(new InputStreamReader(is));
                    subLevels.get(0).setLevelNumber(subLevels.get(0).getLevelNumber() + 1);
                    subLevels.get(0).setLevelNumber(levelNumber);
                    level = new GameLevel(subLevels.get(0), animationRunner, score, livesCounter, keyboardSensor,
                            gui, levelNumber);
                    level.initialize();
                }
            }
            if (livesCounter.getValue() == 0) { //lose
                this.animationRunner.run(new KeyPressStoppableAnimation(this.keyboardSensor, "space",
                        new EndScreenLose(this.keyboardSensor, this.score)));
                break;
            }
        }
        /*while (livesCounter.getValue() != 0) { //win
            List<LevelInformation> subLevels = new ArrayList<>();
            InputStream is = ClassLoader.getSystemClassLoader().getResourceAsStream
                    ("resources/definitions/easy_level_definitions.txt");
            subLevels = new LevelSpecificationReader().fromReader(new InputStreamReader(is));
            subLevels.get(0).setLevelNumber(subLevels.get(0).getLevelNumber() + 1);
            int num = subLevels.get(0).getLevelNumber() + 1;
            subLevels.get(0).setLevelNumber(num);
        }*/
        if (table.getRank(this.score.getValue()) <= table.size()) { //high score is saved
            String name = dialog.showQuestionDialog("Name", "What is your name?", "");
            ScoreInfo scoreInfo = new ScoreInfo(name, this.score.getValue());
            table.add(scoreInfo);
            try {
                table.save(highscores);
            } catch (IOException e) {
                System.out.println(e);
            }
        }
        //shows the score table
        this.animationRunner.run(new KeyPressStoppableAnimation(this.keyboardSensor, "space",
                new HighScoresAnimation(table)));
    }

    /**
     * shows the menu to the screen and operate accordingly.
     *
     * @param levelsSet a set of levels
     */
    public void gameMenu(LevelSets levelsSet) {
        File highscores = new File("highscores");
        if (highscores.exists()) {
            try {
                table.load(highscores);
            } catch (IOException e) {
                System.out.println(e);
            }
        } else {
            try {
                table.save(highscores);
            } catch (IOException e) {
                System.out.println(e);
            }
        }
        Menu<Task<Void>> menu = new MenuAnimation<Task<Void>>(this.keyboardSensor, this.animationRunner);
        menu.addSelection("s", "(s) Start game", new Task<Void>() {
            @Override
            public Void run() {
                List<LevelInformation> subLevels = new ArrayList<>();
                InputStream is = ClassLoader.getSystemClassLoader().getResourceAsStream("resources"
                        + "/definitions/space_invaders_definitions.txt");
                subLevels = new LevelSpecificationReader().fromReader(new InputStreamReader(is));
                runLevels(subLevels);
                return null;
            }
        });
        menu.addSelection("h", "(h) High scores", new Task<Void>() {
            @Override
            public Void run() {
                animationRunner.run(new KeyPressStoppableAnimation(keyboardSensor, "space",
                        new HighScoresAnimation(table)));
                return null;
            }
        });
        menu.addSelection("e", "(e) Exit", new Task<Void>() {
            @Override
            public Void run() {
                gui.close();
                return null;
            }
        });
        while (true) { //shows the menu
            animationRunner.run(menu);
            Task<Void> runTask = (Task) menu.getStatus();
            runTask.run();
            menu.setStop(false);
        }
    }
}