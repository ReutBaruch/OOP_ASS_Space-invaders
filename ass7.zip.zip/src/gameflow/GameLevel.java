package gameflow;

import animation.KeyPressStoppableAnimation;
import gameobjects.GameEnvironment;
import gameobjects.LevelInformation;
import gameobjects.SpriteCollection;
import gameobjects.AlienGroup;
import gameobjects.AlienColumn;
import gameobjects.Paddle;
import gameobjects.Sprite;
import gameobjects.Collidable;
import gameobjects.Block;
import gameobjects.Rectangle;
import gameobjects.Point;
import indicator.Counter;
import indicator.LevelIndicator;
import indicator.LivesIndicator;
import indicator.ScoreIndicator;
import animation.Animation;
import listener.BallRemover;
import listener.BlockRemover;
import listener.PaddleRemover;
import listener.ScoreTrackingListener;
import biuoop.DrawSurface;
import biuoop.GUI;
import biuoop.KeyboardSensor;
import biuoop.Sleeper;
import java.awt.Color;
import java.util.List;

/**
 * the class creates a new gameflow.
 * draws everything to the screen and starts the gameflow.
 */
public class GameLevel implements Animation {
    private SpriteCollection sprites;
    private GameEnvironment environment;
    private LevelInformation levelInformation;
    private Counter blockCounter;
    private Counter ballCounter;
    private Counter scoreCounter;
    private Counter livesCounter;
    private int direction;
    private boolean havePaddle;
    private int levelNumber;
    private AlienColumn ac;
    private AlienGroup ag;
    private Paddle paddle;
    private animation.AnimationRunner runner;
    private boolean running;
    private GUI gui;
    private Sleeper sleeper;
    private biuoop.KeyboardSensor keyboard;
    private static final int PADDLE_HEIGHT = 20;
    private static final int WIDTH_BORDER = 20;
    private static final int FRAME_WIDTH = 800;
    private static final int HEIGHT_BORDER = 580;
    private static final int INFO_LINE = 30;
    private static final int SCREEN_MIDDLE = 380;
    private static final int POINT_REMOVE = 10;

    /**
     * constructor.
     * @param level all the level information.
     * @param ar an animation runner.
     * @param score counter that keep the score.
     * @param livesCounter counter that counts lives.
     * @param ks KeyboardSensor.
     * @param gui gui.
     * @param directionTemp the direction the aliens should go to
     */
    public GameLevel(LevelInformation level, animation.AnimationRunner ar, Counter score, Counter livesCounter,
                     KeyboardSensor ks, biuoop.GUI gui, int directionTemp) {
        this.environment = new GameEnvironment();
        this.sprites = new SpriteCollection();
        this.blockCounter = new Counter();
        this.ballCounter = new Counter();
        this.scoreCounter = score;
        this.livesCounter = livesCounter;
        this.levelInformation = level;
        this.runner = ar;
        this.keyboard = ks;
        this.gui = gui;
        this.direction = directionTemp;
        this.havePaddle = true;
    }

    /**
     * sets the sprites.
     */
    public void setSprites() {
        this.sprites = new SpriteCollection();
    }

    /**
     * sets the gameflow environment.
     */
    public void setEnvironment() {
        this.environment = new GameEnvironment();
    }

    /**
     * if paddle exists.
     * @param a true or false
     */
    public void setHavePaddle(boolean a) {
        this.havePaddle = a;
    }

    /**
     * getter.
     * @return game environment
     */
    public GameEnvironment getEnvironment() {
        return this.environment;
    }

    /**
     * getter.
     * @return AlienGroup
     */
    public AlienGroup getAlienGroup() {
        return this.ag;
    }

    /**
     * getter.
     * @return livesCounter
     */
    public Counter getLivesCounter() {
        return livesCounter;
    }

    /**
     * getter.
     * @return Level Number
     */
    public int getLevelNumber() {
        return this.levelInformation.getLevelNumber();
    }

    /**
     * getter.
     * @return the number of remaining blocks.
     */
    public Counter getBlockCounter() {
        return this.blockCounter;
    }

    /**
     * getter.
     * @return ballCounter
     */
    public Counter getBallsCounter() {
        return this.ballCounter;
    }

    /**
     * adds a collidable to the gameflow environment.
     * @param c a collidable
     */
    public void addCollidable(Collidable c) {
        environment.addCollidable(c);
    }

    /**
     * adds a sprite to the sprites.
     * @param s a sprite.
     */
    public void addSprite(Sprite s) {
        sprites.addSprite(s);
    }

    /**
     * creates the paddle.
     * @param width the width
     * @param speed the speed
     * @param pointForPaddle the begging point
     */
    public void createPaddle(int width, int speed, Point pointForPaddle) {
        PaddleRemover paddleRemover = new PaddleRemover(this);
        keyboard = gui.getKeyboardSensor();
        Rectangle rectForPaddle = new Rectangle(pointForPaddle, width, PADDLE_HEIGHT);
        Block forPaddle = new Block(rectForPaddle, Color.YELLOW);
        paddle = new Paddle(forPaddle, speed,  keyboard);
        paddle.addHitListener(paddleRemover);
        paddle.addToGame(this);
    }

    /**
     * creates an info block.
     */
    public void createInfoBlock() {
        Point p = new Point(0, 0);
        Rectangle rectangle = new Rectangle(p, FRAME_WIDTH, 30);
        Block b = new Block(rectangle, Color.lightGray);
        b.addToGame(this);
        b.setHits(0);
    }

    /**
     * creates removable blocks on the screen.
     * @param blocks a list of blocks that needs to be created.
     */
    public void createBlock(List<Block> blocks) {
        BlockRemover blockRemover = new BlockRemover(this, blockCounter);
        ScoreTrackingListener score = new ScoreTrackingListener(this.scoreCounter);
        ag = new AlienGroup(this.direction);
        ac = new AlienColumn();
        //blocks.get(i).setHits(1);
        for (int j = 0; j < 10; j++) {
            ac = new AlienColumn();
            for (int k = j; k < 50; k = k + 10) {
                blocks.get(k).addHitListener(blockRemover);
                blocks.get(k).addHitListener(score);
                blocks.get(k).addToGame(this);
                blockCounter.increase(1);
                ac.addAlienToColumn(blocks.get(k));
            }
            ag.addColumn(ac);
            ac.addToGame(this);
        }
        ag.addToGame(this);
    }

    /**
     * create the shields.
     */
    public void createShield() {
        int spaceLength = 50;
        int numOfBlocks = 40;
        BlockRemover blockRemover = new BlockRemover(this, blockCounter);
        ScoreTrackingListener score = new ScoreTrackingListener(this.scoreCounter);
        for (int i = 0; i < 3; i++) {
            int x = spaceLength * (i + 1) + 200 * i;
            for (int k = 0; k < 4; k++) {
                for (int j = 0; j < numOfBlocks; j++) {
                    Block s = new Block(new Point(x + 5 * j, 500 + 5 * k), 5, 5, Color.cyan, 1, false);
                    s.addHitListener(blockRemover);
                    s.addHitListener(score);
                    s.addToGame(this);
                }
            }
        }
    }

    /**
     * removes a collidable from the game.
     * @param c a collidable
     */
    public void removeCollidable(Collidable c) {
        environment.removeCollidable(c);
    }

    /**
     * remove sprite from game.
     * @param s a sprite
     */
    public void removeSprite(Sprite s) {
        sprites.removeSprite(s);
    }

    /**
     * Initialize a new gameflow: create the Blocks and gameobjects.Ball (and gameobjects.Paddle)
     * and add them to the gameflow.
     */
    public void initialize() {
        sleeper = new Sleeper();
        sprites.addSprite(levelInformation.getBackground());
        this.runner = new animation.AnimationRunner(60, gui);
        BallRemover ballRemover = new BallRemover(this, ballCounter);
        ScoreIndicator scoreIndicator = new ScoreIndicator(scoreCounter);
        LivesIndicator livesIndicator = new LivesIndicator(livesCounter);
        LevelIndicator levelIndicator = new LevelIndicator(levelInformation.getLevelNumber());
        createPaddle(levelInformation.paddleWidth(), levelInformation.paddleSpeed(), levelInformation.paddlePoint());
        createInfoBlock();
        createBlock(levelInformation.blocks());
        createShield();
        scoreIndicator.addToGame(this);
        livesIndicator.addToGame(this);
        levelIndicator.addToGame(this);
    }

    /**
     * plays one turn in the game.
     */
    public void playOneTurn() {
        this.runner.run(new animation.CountdownAnimation(2, 3, sprites)); // countdown before turn starts.
        this.running = true;
        // use our runner to run the current animation -- which is one turn of
        // the gameflow.
        this.runner.run(this);
    }

    /**
     * as long as there are more blocks to destroy.
     * and there are more lives.
     * runs the game.
     */
    public void run() {
        while (livesCounter.getValue() != 0) { //still have lives
            if (this.blockCounter.getValue() == 0) {
                gui.close();
                return;
            }
            playOneTurn(); //plays
        }
        gui.close();
    }

    /**
     * runs each frame of the game and takes care of the game logic.
     * @param d a draw surface.
     * @param dt the change in the velocity
     */
    @Override
    public void doOneFrame(DrawSurface d, double dt) {
        this.sprites.drawAllOn(d);
        this.sprites.notifyAllTimePassed(dt, this);
        if (this.keyboard.isPressed("p")) { //in order to pause the game
            this.runner.run(new KeyPressStoppableAnimation(this.keyboard, "space",
                    new animation.PauseScreen(this.keyboard)));
        }
        if (blockCounter.getValue() == 0) { //if the level was finished
            scoreCounter.increase(100);
            this.running = false;
        }
        if (!havePaddle) {
            livesCounter.decrease(1);
            this.running = false;
            this.setHavePaddle(true);
            ag.setBlocksToStart(this);
            createPaddle(levelInformation.paddleWidth(), levelInformation.paddleSpeed(),
                    levelInformation.paddlePoint());
        }
        if (livesCounter.getValue() == 0) { //lost all the lives
            this.running = false;
        }
    }

    /**
     * stop condition.
     * @return true or false
     */
    @Override
    public boolean shouldStop() {
        return !this.running;
    }
}
